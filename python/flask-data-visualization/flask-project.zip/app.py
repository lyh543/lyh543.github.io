from flask import Flask
from data_view import data_provider
from page_view import page_provider
from flask_sqlalchemy import SQLAlchemy
import pymysql

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "mysql://root:lyh54333@localhost:3306/test_db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)

app.register_blueprint(data_provider, url_prefix='/data')
app.register_blueprint(page_provider, url_prefix='/page')


class CityCount(db.Model):
    # 该表与数据库表形成映射关系
    __tablename__ = 'city_count'
    city = db.Column(db.String(50), primary_key=True)
    count = db.Column(db.INTEGER)

@app.route('/')
def hello_world():
    return 'Hello World!'


if __name__ == '__main__':
    app.run()
