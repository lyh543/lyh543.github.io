import json
from flask import Blueprint

data_provider = Blueprint('data_provider', __name__)

@data_provider.route('/get_city_count', endpoint='get_city_count')
def get_city_count():
    from app import db, CityCount
    dic = {}
    data = db.session.query(CityCount).all()
    # data = list(map(lambda x: {'city': x.city, 'count': x.count}, data))
    dic['xAxis_data'] = [x.city for x in data]
    dic['series_data'] = [x.count for x in data]

    return json.dumps(dic)
