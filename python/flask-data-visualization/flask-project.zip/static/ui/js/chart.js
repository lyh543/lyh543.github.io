$(function () {
    chart3.get_data();
}); // $表示 HTML 代码加载完以后再执行这段 js

// 定义 chart3 类及其成员函数
var chart3 = {
    get_data: function() {
        $.ajax({
            url:'/data/get_city_count',
            type: 'GET', // 向这个链接发起请求
            dataType: 'json',
            success: function(data) { //执行成功以后的回调函数
                chart3.render(data);
            }
        })
    },
    render: function (data) { //给函数定义添加了输入参数
        // 原 chart3 函数定义的第一行，目的应该是替换掉 HTML 代码中 id 为 chart3 的 div
        // 这里删去了 chart3 函数定义中 myCharts 相关代码
        var myChart = echarts.init(document.getElementById('chart3'));
        // 原 chart3 函数定义的第三行，目的应该是当窗口大小变化时，自动调整 myChart 的大小
        window.addEventListener('resize', function () {
            myChart.resize();
        });

        //下面照抄 Echarts 实例网站给的 Option
        var option = {
            xAxis: {
                type: 'category',
                data: data.xAxis_data //xAxis_data 是在 data_view.py 定义的
            },
            yAxis: {
                type: 'value'
            },
            series: [{
                data: data.series_data,
                type: 'bar',
                showBackground: true,
                backgroundStyle: {
                    color: 'rgba(220, 220, 220, 0.8)'
                }
            }]
        };

        // 原 chart3 函数定义的最后一行，目的应该是使用 option 对 myChart 进行设置
        myChart.setOption(option);
    }
};